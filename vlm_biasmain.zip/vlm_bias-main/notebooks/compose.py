import random
import torch
from PIL import Image
import numpy as np

from rembg import remove


#---------------------
input_path = 'man_poor.png'
input_path = 'man_rich.png'
output_path = input_path[:-4] + "_nobg.png"

input = Image.open(input_path)
output = remove(input)
output.save(output_path)

#---------------------
scene_path = "scene_empty.png"
char_path = "man_rich_nobg.png"
char2_path = "man_poor_nobg.png"

bg = Image.open(scene_path)

char = Image.open(char_path)
char_size = np.array(char).shape
char = char.resize((int(char_size[0]*0.4), int(char_size[1]*0.4)))
char_alpha = char.split()[3]

char2 = Image.open(char2_path)
char2_size = np.array(char2).shape
char2 = char2.resize((int(char2_size[0]*0.4), int(char2_size[1]*0.4)))
char2_alpha = char2.split()[3]

np.array(bg).shape, np.array(char).shape, np.array(char2).shape

#---------------------

# left side
x, y = (bg.size[0] // 2 - char.size[0]) // 2, bg.size[1] - char.size[1]
bg.paste(char, (x, y), mask=char_alpha)

# right side
x, y = (bg.size[0] // 2) + (bg.size[0] // 2 - char2.size[0]) // 2, bg.size[1] - char2.size[1]
bg.paste(char2, (x, y), mask=char2_alpha)

bg.save("scene_chars.png","PNG")
print(np.array(bg).shape)
bg

#---------------------
